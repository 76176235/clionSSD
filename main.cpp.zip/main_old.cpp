#include <iostream>
#include <string>

#include <opencv2/core.hpp>
#include <opencv2/core/cvdef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/dnn/shape_utils.hpp>

#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

#include <stdio.h>
#include <stdlib.h>

#include <fstream>
#include <cstdlib>


using namespace cv;
using namespace std;
dnn::Net net;

const size_t inWidth = 300;
const size_t inHeight = 300;
const float WHRatio = inWidth / (float)inHeight;

const char* classNamesSSD[] = {
        "BG0", "person", "bicycle", "car", "motorcycle", "airplane",
        "bus", "train", "truck", "boat", "traffic light",
        "fire hydrant", "BG1", "stop sign", "parking meter", "bench", "bird",
        "cat", "dog", "horse", "sheep", "cow", "elephant", "bear",
        "zebra", "giraffe", "BG2", "backpack", "umbrella", "BG3", "BG4", "handbag", "tie",
        "suitcase", "frisbee", "skis", "snowboard", "sports ball",
        "kite", "baseball bat", "baseball glove", "skateboard",
        "surfboard", "tennis racket", "bottle", "BG5", "wine glass", "cup",
        "fork", "knife", "spoon", "bowl", "banana", "apple",
        "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza",
        "donut", "cake", "chair", "couch", "potted plant", "bed", "BG6",
        "dining table", "BG7", "BG8", "toilet", "BG9", "tv", "laptop", "mouse", "remote",
        "keyboard", "cell phone", "microwave", "oven", "toaster",
        "sink", "refrigerator", "BG10", "book", "clock", "vase", "scissors",
        "teddy bear", "hair drier", "toothbrush"
};

String modelFile = "./frozen_inference_graph.pb";
String prototextFile = "./ssd_mobilenet_v1_coco.pbtxt";

int main() {
    std::cout << "Hello, World!" << std::endl;

    net = dnn::readNetFromTensorflow(modelFile, prototextFile);
    cv::Mat frame;
    //image_real = cv::imread("/home/zpc/Mask_RCNN-master/images/3862500489_6fd195d183_z.jpg");
    //image_real = cv::imread("/home/whao/Mask_RCNN-master/images/7933423348_c30bd9bd4e_z.jpg");
    frame = cv::imread("/home/whao/Pictures/16.jpg");

    Size frame_size = frame.size();

    Size cropSize;
    if (frame_size.width / (float)frame_size.height > WHRatio)
    {
        cropSize = Size(static_cast<int>(frame_size.height * WHRatio),
                        frame_size.height);
    }
    else
    {
        cropSize = Size(frame_size.width,
                        static_cast<int>(frame_size.width / WHRatio));
    }

    Rect crop(Point((frame_size.width - cropSize.width) / 2,
                    (frame_size.height - cropSize.height) / 2),
              cropSize);

    cv::Mat blob = cv::dnn::blobFromImage(frame,1./255,Size(300,300));

    net.setInput(blob);
    Mat output = net.forward();

    Mat detectionMat(output.size[2], output.size[3], CV_32F, output.ptr<float>());

    frame = frame(crop);

    float confidenceThreshold = 50 * 0.01;
    for (int i = 0; i < detectionMat.rows; i++)
    {
        float confidence = detectionMat.at<float>(i, 2);
        if (confidence > confidenceThreshold){

            size_t objectClass = (size_t)(detectionMat.at<float>(i, 1));

            int xLeftBottom = static_cast<int>(detectionMat.at<float>(i, 3) * frame.cols);
            int yLeftBottom = static_cast<int>(detectionMat.at<float>(i, 4) * frame.rows);
            int xRightTop = static_cast<int>(detectionMat.at<float>(i, 5) * frame.cols);
            int yRightTop = static_cast<int>(detectionMat.at<float>(i, 6) * frame.rows);

            ostringstream ss;
            ss << confidence;
            String conf(ss.str());

            Rect object((int)xLeftBottom, (int)yLeftBottom,
                        (int)(xRightTop - xLeftBottom),
                        (int)(yRightTop - yLeftBottom));

            rectangle(frame, object, Scalar(0, 255, 0),2);
            String label = String(classNamesSSD[objectClass]) + ": " + conf;
            int baseLine = 0;
            Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
            rectangle(frame, Rect(Point(xLeftBottom, yLeftBottom - labelSize.height),
                                  Size(labelSize.width, labelSize.height + baseLine)),
                      Scalar(0, 255, 0), CV_FILLED);
            putText(frame, label, Point(xLeftBottom, yLeftBottom),
                    FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 0, 0));
        }
    }

    imshow("result_SSD",frame);
    cv::waitKey(0);

    return 0;
}