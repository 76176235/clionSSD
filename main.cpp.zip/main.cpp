#include <iostream>
#include <string>

#include <opencv2/core.hpp>
#include <opencv2/core/cvdef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/dnn/shape_utils.hpp>

#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

#include <stdio.h>
#include <stdlib.h>

#include <fstream>
#include <cstdlib>

#include "utils.h"

using namespace cv;
using namespace std;
dnn::Net net;

const size_t inWidth = 300;
const size_t inHeight = 300;
const float WHRatio = inWidth / (float)inHeight;

String modelFile = "./frozen_inference_graph.pb";
String prototextFile = "./ssd_mobilenet_v1_coco.pbtxt";

int main() {



    net = dnn::readNetFromTensorflow(modelFile, prototextFile);

    string file_path = "/home/whao/clion_ssd/cmake-build-debug/images/";

    for (int i = 1; i <= 30; i = i + 1) {

        string image_path = file_path + to_string(i) + ".jpg";
        Mat image_real = imread(image_path);

        cv::Mat frame;
        //image_real = cv::imread("/home/whao/test_tf/cmake-build-debug/images/2948.jpg");
        //image_real = cv::imread("/home/whao/Mask_RCNN-master/images/3862500489_6fd195d183_z.jpg");
        //image_real = cv::imread("/home/whao/Mask_RCNN-master/images/7933423348_c30bd9bd4e_z.jpg");
        //image_real = cv::imread("/home/whao/Mask_RCNN-master/images/9247489789_132c0d534a_z.jpg");
        frame = image_real.clone();
        pair<float, vector<int> > scale_window = resize_image(frame, 300, 300);

        cv::Mat blob = cv::dnn::blobFromImage(frame, 1. / 255, Size(300, 300));

        net.setInput(blob);
        Mat output = net.forward();

        Mat detectionMat(output.size[2], output.size[3], CV_32F, output.ptr<float>());

        //    cout<<detectionMat<<endl;

        int img_height = frame.rows;
        int img_width = frame.cols;
        Mat mat_window = Mat(1, 4, CV_32SC1, scale_window.second.data());
        mat_window.convertTo(mat_window, CV_32FC1);
        norm_boxes(mat_window, img_height, img_width);

        float wy1 = mat_window.at<float>(0, 0), wx1 = mat_window.at<float>(0, 1),
                wy2 = mat_window.at<float>(0, 2), wx2 = mat_window.at<float>(0, 3);

        float shift[4] = {wy1, wx1, wy1, wx1};
        Mat mat_shift = Mat(1, 4, CV_32FC1, &shift);
        float scale[4] = {wy2 - wy1, wx2 - wx1, wy2 - wy1, wx2 - wx1};
        Mat mat_scale = Mat(1, 4, CV_32FC1, &scale);

        float confidenceThreshold = 1 * 0.05;
        for (int i = 0; i < detectionMat.rows; i++) {
            bool flagClassTH = false;

            float confidence = detectionMat.at<float>(i, 2);

            if(detectionMat.at<float>(i, 1) == 1){
                if(detectionMat.at<float>(i, 2) >= 0.3) {
                    flagClassTH = true;
                }
            }
            else if(detectionMat.at<float>(i, 1) == 17){
                if(detectionMat.at<float>(i, 2) >= 0.01) {
                    flagClassTH = true;
                }
            }
            else
            {
                if(detectionMat.at<float>(i, 2) >= 0.2) {
                    flagClassTH = true;
                }
            }
            if (flagClassTH)
            {
                if (confidence > confidenceThreshold) {

                    size_t objectClass = (size_t) (detectionMat.at<float>(i, 1));

                    float boxes[4] = {detectionMat.at<float>(i, 4), detectionMat.at<float>(i, 3),
                                      detectionMat.at<float>(i, 6), detectionMat.at<float>(i, 5)};
                    Mat det_boxes = Mat(1, 4, CV_32FC1, &boxes);
                    det_boxes = (det_boxes - mat_shift) / mat_scale;
                    denorm_boxes(det_boxes, image_real.rows, image_real.cols);

                    int xLeftBottom = det_boxes.at<int>(0, 1);
                    int yLeftBottom = det_boxes.at<int>(0, 0);
                    int xRightTop = det_boxes.at<int>(0, 3);
                    int yRightTop = det_boxes.at<int>(0, 2);

                    ostringstream ss;
                    ss << confidence;
                    String conf(ss.str());

                    Rect object((int) xLeftBottom, (int) yLeftBottom,
                                (int) (xRightTop - xLeftBottom),
                                (int) (yRightTop - yLeftBottom));

                    rectangle(image_real, object, Scalar(0, 255, 0), 2);
                    String label = String(classNamesSSD[objectClass]) + ": " + conf;
                    int baseLine = 0;
                    Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
                    rectangle(image_real, Rect(Point(xLeftBottom, yLeftBottom - labelSize.height),
                                               Size(labelSize.width, labelSize.height + baseLine)),
                              Scalar(0, 255, 0), CV_FILLED);
                    putText(image_real, label, Point(xLeftBottom, yLeftBottom),
                            FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 0, 0));

                    //            imshow("result_SSD",image_real);
                    //            cv::waitKey(0);
                }
            }
        }

        imwrite( file_path + to_string(i) + "out" + ".jpg", image_real);
//        imshow("result_SSD", image_real);
//        cv::waitKey(0);
    }
    return 0;
}